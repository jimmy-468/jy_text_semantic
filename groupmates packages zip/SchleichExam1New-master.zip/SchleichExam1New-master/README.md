Exam Asignment: Sliding Window

load ggplot2
download the dependencies and files (test data in init file and test code in test file)
Caviates: 
-I coudnt figure out to to do only the window function and then only the itterative function so i did it in a one pot fucntion
-Also threshold instructions were unclear...to which function was that supposed to be added? I left it out. 
Happy that it worked after all. 
