# jy_text_semantic
Coding exercise, package for summarising negative and positive words in a document. KI-course H7F6003 assignment.

Consists of a wrapper function for end user interaction: jy_text_analyser())
and 2 helper functions: jy_text_file_reader() and jy_pos_neg_words()

Test the function through following code
jy_text_analyser("../data/Example_negative.txt")

The quiz/tasks markdownfiles (eg. day 6 tidyverse) are in the "QUIZ N TASKS"-folder
